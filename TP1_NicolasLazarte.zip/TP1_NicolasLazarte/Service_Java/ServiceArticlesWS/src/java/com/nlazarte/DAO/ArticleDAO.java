/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.nlazarte.DAO;

import com.nlazarte.DTO.Article;
import com.nlazarte.jidbc.DataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author Mapple
 */
public class ArticleDAO {
        public boolean  Create(Article p)
    {
        try
        {

            Connection conn = DataBase.getInstance();
            PreparedStatement stm = conn.prepareStatement("INSERT INTO article (id,annee,titre,edition) VALUES (?,?,?,?)");
            stm.setInt(1, p.getId());
            stm.setInt(2, p.getAnnee());
            stm.setString(3, p.getTitre());
            stm.setString(4, p.getEdition());
            stm.executeUpdate();


            stm.close();
            conn.close();
            return true;

        }
        catch(Exception e)
        {
             System.out.println(e.getMessage());
        }
        return false;
    }
}
