/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.nlazarte.DTO;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Mapple
 */
@XmlRootElement
public class Article implements Serializable {
    
    private int id;
    private int annee;
    private String titre;
    private String edition;

    public Article()
    {}

    public Article(int id, int annee, String titre, String edition){
        this.id = id;
        this.annee = annee;
        this.titre = titre;
        this.edition = edition;
     }

    public int getId() {
        return id;
    }

    public int getAnnee() {
        return annee;
    }

    public String getTitre() {
        return titre;
    }

    public String getEdition() {
        return edition;
    }

    public void setId(int articleId) {
        this.id = articleId;
    }

    public void setAnnee(int anneeArticle) {
        this.annee = anneeArticle;
    }

    public void setTitre(String titreArticle) {
        this.titre = titreArticle;
    }

    public void setEdition(String editionArticle) {
        this.edition = editionArticle;
    }
       
}
