/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.nlazarte.ws;

import com.nlazarte.DAO.ArticleDAO;
import com.nlazarte.DTO.Article;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author Mapple
 */
@WebService(serviceName = "ServiceArticle")
public class ServiceArticle {

    /**
     * This is a sample web service operation
     * @param p
     * @return 
     */
    @WebMethod(operationName = "AjoutArticle")
    public boolean ajouterArticle(@WebParam(name = "Article") Article a ) {
        ArticleDAO dao =new ArticleDAO();
        boolean resultat = dao.Create(a);
        
        return resultat;
    }
}

