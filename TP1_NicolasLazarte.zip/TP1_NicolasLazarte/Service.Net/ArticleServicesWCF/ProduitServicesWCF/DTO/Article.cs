﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ProduitServicesWCF.DTO
{
    [DataContract]
    public class Article
    {
        public Article()
        {

        }

        public Article(int id, int annee, String titre, String edition)
        {
            this.id = id;
            this.annee = annee;
            this.titre = titre
            this.edition = edition;
        }

        [DataMember]
        public int id { get; set; }
        [DataMember]
        public int annee { get; set; }
        [DataMember]
        public String titre { get; set; }
        [DataMember]
        public String edition { get; set; }
    }
}
