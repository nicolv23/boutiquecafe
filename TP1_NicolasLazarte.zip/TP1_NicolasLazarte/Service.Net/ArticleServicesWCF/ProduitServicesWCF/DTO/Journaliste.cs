﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ProduitServicesWCF.DTO
{
    [DataContract]
    public class Journaliste
    {
        public Journaliste()
        {

        }

        public Journaliste(int Id, string Nom, string Prenom, string Entreprise, string Ville)
        {
            this.Id = Id;
            this.Nom = Nom;
            this.Prenom = Prenom;
            this.Entreprise = Entreprise;
            this.Ville = Ville;
        }
        [DataMember]
        public int Id { get; set; }

        [DataMember]
        public string Nom { get; set; }

        [DataMember]
        public string Prenom { get; set; }


        [DataMember]
        public string Entreprise { get; set; }


        [DataMember]
        public string Ville { get; set; }
    }
}
