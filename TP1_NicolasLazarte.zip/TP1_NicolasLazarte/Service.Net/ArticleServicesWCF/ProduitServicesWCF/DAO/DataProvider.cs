﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProduitServicesWCF.DTO;

namespace ProduitServicesWCF.DAO
{
    internal class DataProvider
    {
        public List<Article> GetArticles()
        {
            List<Article> resultats = new List<Article>();
            Article article;

            DbConnection cnx = new MySqlConnection();
            cnx.ConnectionString = "server=localhost;user=root;password=root;database=articles;";

            cnx.Open();


            DbCommand cmd = new MySqlCommand(); //Ou : MySqlCommand cmd = cnx.CreateCommand();
            cmd.Connection = cnx;
            cmd.CommandText = "article";
            cmd.CommandType = CommandType.TableDirect;

            DbDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                article = new Article();

                article.id = (int)dr["Id"];
                article.annee = (int)dr["annee"];
                article.titre = (string)dr["titre"];
                article.edition = (string)dr["edition"];

                resultats.Add(article);
            }
            cnx.Close();
            return resultats;
        }

        public void AjouterArticle(Article article)
        {
            DbConnection cnx = new MySqlConnection();

            cnx.ConnectionString = "server=localhost;user=root;password=root;database=articles;";

            cnx.Open();

            DbCommand cmd = new MySqlCommand(); //Ou : MySqlCommand cmd = cnx.CreateCommand();
            cmd.Connection = cnx;

            // Create and prepare an SQL statement.
            cmd.CommandText =
                "INSERT INTO article (id,annee,titre,edition) " +
                "VALUES (@id,@annee,@titre,@edition)";

            // MySqlParameter idParam = new MySqlParameter("@id", SqlDbType.Int, 0);
            MySqlParameter id = new MySqlParameter("@id", MySqlDbType.Int32);
            MySqlParameter annee = new MySqlParameter("@annee", MySqlDbType.VarChar);
            MySqlParameter titre = new MySqlParameter("@titre", MySqlDbType.VarChar);
            MySqlParameter edition = new MySqlParameter("@edition", MySqlDbType.VarChar);

            //idParam.Value = commande.CommandeId;

            id.Value = .id;
            annee.Value = commande.annee;
            titre.Value = commande.NomProduit;
            edition.Value = Convert.ToInt32(commande.Quantite);

            //cmd.Parameters.Add(idParam);
            cmd.Parameters.Add(nomFermierParam);
            cmd.Parameters.Add(nomFermeParam);
            cmd.Parameters.Add(nomProduitParam);
            cmd.Parameters.Add(quantiteParam);

            cmd.Prepare();
            cmd.ExecuteNonQuery();

        }

    }
}

