/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clientproduitservicewcf;
import com.tbellal.client.*;
import java.util.Scanner;
import javax.xml.bind.JAXBElement;

/**
 *
 * @author toufi
 */
public class ClientProduitServiceWCF {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Service1 service = new Service1();
        IService1 port = service.getBasicHttpBindingIService1();
        
        ArrayOfProduit produits;
        Commande commande = new Commande();
        ObjectFactory factory = new ObjectFactory();
        Scanner input = new Scanner(System.in);
        
        while (true) 
        {
            System.out.println("Choisissez entre les deux options suivantes :");
            System.out.println("Taper 1  : Pour avoir la listes des produits.");
            System.out.println("Taper 2  : Pour faire une commande.");
           
        int reponse = input.nextInt();
        input.nextLine();
        switch (reponse) {
            case 1:
                produits = port.getProduits();
                  for(int i=0; i< produits.getProduit().size(); i++)
                    System.out.println("Id produit : "+ produits.getProduit().get(i).getProduitId()+" ---- Nom produit : " +(produits.getProduit().get(i).getNomProduit().getValue())+ "  ---- Quantite : " +produits.getProduit().get(i).getQuantite()+ "  ----- Prix : " +produits.getProduit().get(i).getPrix());
                break;
            case 2:
                System.out.println("Entrez votre nom : ");
                JAXBElement<String> NomFermier  = factory.createCommandeNomFermier(input.nextLine());
                commande.setNomFermier(NomFermier);
                System.out.println("Entrez le nom de votre ferme : ");
                JAXBElement<String> NomFerme  = factory.createCommandeNomFerme(input.nextLine());
                commande.setNomFerme(NomFerme);
                System.out.println("Entrez le nom du produit: ");
                  JAXBElement<String> NomProduit  = factory.createCommandeNomProduit(input.nextLine());
                commande.setNomProduit(NomProduit);
                
                System.out.println("Entrez la qauntité desirée: ");
                  commande.setQuantite(input.nextInt());
                port.ajouterCommande(commande);
                break;
            default:
                System.out.println("Entrer une valeur valide.");
                break;
       
        }
            
        }
        
        
    }
    
}
