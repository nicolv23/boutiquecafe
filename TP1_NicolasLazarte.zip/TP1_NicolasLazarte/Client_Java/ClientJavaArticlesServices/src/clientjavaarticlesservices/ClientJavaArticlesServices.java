/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clientjavaarticlesservices;

import com.nlazarte.client.Article;
import com.nlazarte.client.ServiceArticle;
import com.nlazarte.client.ServiceArticle_Service;
import java.util.Scanner;

/**
 *
 * @author Nicolas Lazarte
 */
public class ClientJavaArticlesServices {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ServiceArticle_Service serv = new ServiceArticle_Service();
        ServiceArticle port = serv.getServiceArticlePort();
        Scanner clavier = new Scanner(System.in);

        System.out.println("Entrez l'id de l'article : ");
        int idArticle = clavier.nextInt();
        
        System.out.println("Entrez le nom de l'article : ");
        String nomArticle = clavier.nextLine();

        System.out.println("Entrez l'annee de l'article : ");
        int annee = clavier.nextInt();

        System.out.println("Entrez l'édition de l'article : ");
        String edition = clavier.nextLine();

        Article a = new Article();
        a.setId(idArticle);
        a.setAnnee(annee);
        a.setTitre(nomArticle); 
        a.setEdition(edition);  
        port.ajoutArticle(a);

        System.out.println("Article ajouté avec succes");
    }
}
