﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientProduitService.ServiceReference1;

namespace ClientProduitService
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ServiceProduitClient service = new ServiceProduitClient();
            Console.WriteLine("Entrez le nom de l'article : ");
            string nomProduit = Console.ReadLine();

            Console.WriteLine("Entrez la Qauntite du produit : ");
            int quantite = Convert.ToInt32(Console.ReadLine());


            Console.WriteLine("Entrez le prix du produit : ");
            double prix = Convert.ToDouble(Console.ReadLine());

            produit p = new produit();
            p.nomProduit = nomProduit;
            p.prix = prix;
            p.quantite = quantite;  

            service.AjoutProduit(p);

            Console.WriteLine("Produit ajouté avec succes");
        }
    }
}
